/**
 * 
 */
/**
 * 
 */
module Hamburgueria {
	requires java.desktop;
}